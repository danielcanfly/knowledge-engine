---
concept_id: "concepts/agent-execution-paths"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/agent-execution-paths#agent-execution-paths"
semantic_serving_enabled: false
---

# Agent execution paths

## Section

- Section title: Agent execution paths
- Concept ID: `concepts/agent-execution-paths`
- Section ID: `concepts/agent-execution-paths#agent-execution-paths`
- Rank: `2`
- Score: `1.0`

## Excerpt

An agent system's execution path defines how work moves from an initial condition to a terminal outcome. It is separate from the decision logic inside an individual node. A state machine may control the outer workflow while one state uses bounded ReAct, and a fixed pipeline ma...

## Sources

- [[sources/002-src-content-blog-the-atlas-of-agent-design-patterns-part-2-en-md|card_784b4fdd68d221c2ecc7a82fbccd790c]] citations `2`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
