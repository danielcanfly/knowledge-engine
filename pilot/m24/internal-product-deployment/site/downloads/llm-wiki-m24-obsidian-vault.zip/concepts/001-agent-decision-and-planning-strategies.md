---
concept_id: "concepts/agent-planning-strategies"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/agent-planning-strategies#adaptive-planning-and-replanning"
semantic_serving_enabled: false
---

# Agent decision and planning strategies

## Section

- Section title: Adaptive planning and replanning
- Concept ID: `concepts/agent-planning-strategies`
- Section ID: `concepts/agent-planning-strategies#adaptive-planning-and-replanning`
- Rank: `1`
- Score: `1.0`

## Excerpt

Adaptive planning revises the remaining plan when execution evidence invalidates a material assumption. It should not rewrite the whole plan after every observation. Valid replan triggers include: - a critical premise becomes false; - required data or a capability is unavailab...

## Sources

- [[sources/003-agent-decision-and-planning-strategies|Agent decision and planning strategies]] citations `1`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
