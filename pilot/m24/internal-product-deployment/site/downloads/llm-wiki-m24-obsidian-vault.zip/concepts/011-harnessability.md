---
concept_id: "concepts/harnessability"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/harnessability#assessment"
semantic_serving_enabled: false
---

# Harnessability

## Section

- Section title: Assessment
- Concept ID: `concepts/harnessability`
- Section ID: `concepts/harnessability#assessment`
- Rank: `11`
- Score: `1.0`

## Excerpt

A highly harnessable workflow has stable inputs, explicit authority, deterministic or inspectable effects, typed failures, replayable evidence, and clear completion gates. Low harnessability calls for smaller scopes, stronger adapters, or human review before automation.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `25, 26, 27`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `25, 26, 27`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `25, 26, 27`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
