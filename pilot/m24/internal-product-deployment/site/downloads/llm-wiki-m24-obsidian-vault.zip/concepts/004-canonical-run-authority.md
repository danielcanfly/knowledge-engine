---
concept_id: "concepts/canonical-run-authority"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/canonical-run-authority#canonical-run-authority"
semantic_serving_enabled: false
---

# Canonical Run Authority

## Section

- Section title: Canonical Run Authority
- Concept ID: `concepts/canonical-run-authority`
- Section ID: `concepts/canonical-run-authority#canonical-run-authority`
- Rank: `4`
- Score: `1.0`

## Excerpt

Canonical run authority is the system of record that owns authoritative run identity, state, transitions, evidence pointers, approvals, and terminal status.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `4, 5, 6`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `4, 5, 6`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `4, 5, 6`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
