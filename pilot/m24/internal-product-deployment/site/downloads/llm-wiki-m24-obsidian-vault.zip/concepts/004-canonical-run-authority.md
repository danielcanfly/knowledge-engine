---
concept_id: "concepts/canonical-run-authority"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/canonical-run-authority#canonical-run-authority"
semantic_serving_enabled: false
---

# Canonical Run Authority

## Section

- Section title: Canonical Run Authority
- Concept ID: `concepts/canonical-run-authority`
- Section ID: `concepts/canonical-run-authority#canonical-run-authority`
- Rank: `4`
- Score: `1.0`

## Excerpt

Canonical run authority is the system of record that owns authoritative run identity, state, transitions, evidence pointers, approvals, and terminal status.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `4, 5, 6`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `4, 5, 6`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `4, 5, 6`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
