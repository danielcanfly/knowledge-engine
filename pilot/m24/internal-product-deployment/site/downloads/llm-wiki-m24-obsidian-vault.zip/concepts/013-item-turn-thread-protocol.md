---
concept_id: "concepts/item-turn-thread-protocol"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/item-turn-thread-protocol#item-turn-thread-protocol"
semantic_serving_enabled: false
---

# Item Turn Thread Protocol

## Section

- Section title: Item Turn Thread Protocol
- Concept ID: `concepts/item-turn-thread-protocol`
- Section ID: `concepts/item-turn-thread-protocol#item-turn-thread-protocol`
- Rank: `13`
- Score: `1.0`

## Excerpt

The item turn thread protocol is a harness interaction model that separates typed interaction items, pausable work turns, and durable threads.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `31, 32, 33`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `31, 32, 33`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `31, 32, 33`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
