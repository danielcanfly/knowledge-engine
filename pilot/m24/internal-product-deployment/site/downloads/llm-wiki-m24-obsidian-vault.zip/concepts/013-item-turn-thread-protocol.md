---
concept_id: "concepts/item-turn-thread-protocol"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/item-turn-thread-protocol#item-turn-thread-protocol"
semantic_serving_enabled: false
---

# Item Turn Thread Protocol

## Section

- Section title: Item Turn Thread Protocol
- Concept ID: `concepts/item-turn-thread-protocol`
- Section ID: `concepts/item-turn-thread-protocol#item-turn-thread-protocol`
- Rank: `13`
- Score: `1.0`

## Excerpt

The item turn thread protocol is a harness interaction model that separates typed interaction items, pausable work turns, and durable threads.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `31, 32, 33`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `31, 32, 33`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `31, 32, 33`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
