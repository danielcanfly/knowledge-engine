---
concept_id: "concepts/source-governance"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/source-governance#knowledge-source-governance"
semantic_serving_enabled: false
---

# Knowledge source governance

## Section

- Section title: Knowledge source governance
- Concept ID: `concepts/source-governance`
- Section ID: `concepts/source-governance#knowledge-source-governance`
- Rank: `14`
- Score: `1.0`

## Excerpt

`knowledge-source` is the human-authored source of truth. Generated indexes, release manifests, runtime caches, R2 snapshots, and Oracle deployment state are outputs rather than authoring inputs. Every source change must pass deterministic validation and review before the Buil...

## Sources

- [[sources/003-https-github-com-danielcanfly-knowledge-os-foundation|card_b9c636612d1fb60a4951a6a0db5f0611]] citations `34`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
