---
concept_id: "concepts/source-governance"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/source-governance#knowledge-source-governance"
semantic_serving_enabled: false
---

# Knowledge source governance

## Section

- Section title: Knowledge source governance
- Concept ID: `concepts/source-governance`
- Section ID: `concepts/source-governance#knowledge-source-governance`
- Rank: `14`
- Score: `1.0`

## Excerpt

`knowledge-source` is the human-authored source of truth. Generated indexes, release manifests, runtime caches, R2 snapshots, and Oracle deployment state are outputs rather than authoring inputs. Every source change must pass deterministic validation and review before the Buil...

## Sources

- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `34`
- [[sources/007-m3-delivery-contract|M3 delivery contract]] citations `34`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
