---
concept_id: "concepts/harness-agent-loop"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/harness-agent-loop#control"
semantic_serving_enabled: false
---

# Harness Agent Loop

## Section

- Section title: Control
- Concept ID: `concepts/harness-agent-loop`
- Section ID: `concepts/harness-agent-loop#control`
- Rank: `9`
- Score: `1.0`

## Excerpt

The loop should expose allowed tools, per-step evidence, retry bounds, duplicate detection, escalation, and completion checks. The model can choose a next proposal only inside those limits.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `19, 20, 21`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `19, 20, 21`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `19, 20, 21`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
