---
concept_id: "concepts/harness-agent-loop"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/harness-agent-loop#control"
semantic_serving_enabled: false
---

# Harness Agent Loop

## Section

- Section title: Control
- Concept ID: `concepts/harness-agent-loop`
- Section ID: `concepts/harness-agent-loop#control`
- Rank: `9`
- Score: `1.0`

## Excerpt

The loop should expose allowed tools, per-step evidence, retry bounds, duplicate detection, escalation, and completion checks. The model can choose a next proposal only inside those limits.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `19, 20, 21`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `19, 20, 21`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `19, 20, 21`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
