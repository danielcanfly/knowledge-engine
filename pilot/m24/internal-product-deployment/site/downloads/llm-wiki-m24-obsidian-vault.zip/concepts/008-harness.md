---
concept_id: "concepts/harness"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/harness#boundary"
semantic_serving_enabled: false
---

# Harness

## Section

- Section title: Boundary
- Concept ID: `concepts/harness`
- Section ID: `concepts/harness#boundary`
- Rank: `8`
- Score: `1.0`

## Excerpt

A harness is not the model itself and is not the generated answer. It is the surrounding product and runtime contract that decides what work may start, what evidence is required, which actions are allowed, when state becomes authoritative, and when the run must stop.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `16, 17, 18`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `16, 17, 18`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `16, 17, 18`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
