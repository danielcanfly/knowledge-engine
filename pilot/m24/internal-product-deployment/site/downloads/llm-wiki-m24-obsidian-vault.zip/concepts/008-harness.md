---
concept_id: "concepts/harness"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/harness#boundary"
semantic_serving_enabled: false
---

# Harness

## Section

- Section title: Boundary
- Concept ID: `concepts/harness`
- Section ID: `concepts/harness#boundary`
- Rank: `8`
- Score: `1.0`

## Excerpt

A harness is not the model itself and is not the generated answer. It is the surrounding product and runtime contract that decides what work may start, what evidence is required, which actions are allowed, when state becomes authoritative, and when the run must stop.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `16, 17, 18`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `16, 17, 18`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `16, 17, 18`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
