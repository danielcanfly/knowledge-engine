---
concept_id: "concepts/completion-gate"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/completion-gate#authority"
semantic_serving_enabled: false
---

# Completion Gate

## Section

- Section title: Authority
- Concept ID: `concepts/completion-gate`
- Section ID: `concepts/completion-gate#authority`
- Rank: `5`
- Score: `1.0`

## Excerpt

Completion is a state transition owned by the harness or by an explicitly named reviewer. A model may propose completion, but it should not be the sole authority for acceptance.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `7, 8, 9`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `7, 8, 9`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `7, 8, 9`
- [[sources/007-m3-delivery-contract|M3 delivery contract]] citations `7, 8, 9`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
