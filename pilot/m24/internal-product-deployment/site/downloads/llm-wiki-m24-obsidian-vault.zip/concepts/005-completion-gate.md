---
concept_id: "concepts/completion-gate"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/completion-gate#authority"
semantic_serving_enabled: false
---

# Completion Gate

## Section

- Section title: Authority
- Concept ID: `concepts/completion-gate`
- Section ID: `concepts/completion-gate#authority`
- Rank: `5`
- Score: `1.0`

## Excerpt

Completion is a state transition owned by the harness or by an explicitly named reviewer. A model may propose completion, but it should not be the sole authority for acceptance.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `7, 8, 9`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `7, 8, 9`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `7, 8, 9`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
