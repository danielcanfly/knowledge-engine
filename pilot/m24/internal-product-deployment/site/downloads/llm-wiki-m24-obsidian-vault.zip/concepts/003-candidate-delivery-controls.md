---
concept_id: "concepts/candidate-delivery-controls"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/candidate-delivery-controls#candidate-delivery-controls"
semantic_serving_enabled: false
---

# Candidate delivery controls

## Section

- Section title: Candidate delivery controls
- Concept ID: `concepts/candidate-delivery-controls`
- Section ID: `concepts/candidate-delivery-controls#candidate-delivery-controls`
- Rank: `3`
- Score: `1.0`

## Excerpt

The quartz lantern protocol is the internal acceptance phrase for the M3 candidate pipeline. A source commit is eligible for candidate publication only when the Builder checks out the exact reviewed SHA, rebuilds the release twice with identical artifacts, uploads immutable ob...

## Sources

- [[sources/003-https-github-com-danielcanfly-knowledge-os-foundation|card_b9c636612d1fb60a4951a6a0db5f0611]] citations `3`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
