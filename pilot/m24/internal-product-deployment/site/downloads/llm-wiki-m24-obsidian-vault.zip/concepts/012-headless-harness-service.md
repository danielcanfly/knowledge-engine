---
concept_id: "concepts/headless-harness-service"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/headless-harness-service#headless-harness-service"
semantic_serving_enabled: false
---

# Headless Harness Service

## Section

- Section title: Headless Harness Service
- Concept ID: `concepts/headless-harness-service`
- Section ID: `concepts/headless-harness-service#headless-harness-service`
- Rank: `12`
- Score: `1.0`

## Excerpt

A headless harness service is a UI-independent execution core that exposes harness operations through a stable protocol rather than tying them to one chat client or browser surface.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `28, 29, 30`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `28, 29, 30`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `28, 29, 30`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
