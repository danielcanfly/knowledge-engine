---
concept_id: "concepts/headless-harness-service"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/headless-harness-service#headless-harness-service"
semantic_serving_enabled: false
---

# Headless Harness Service

## Section

- Section title: Headless Harness Service
- Concept ID: `concepts/headless-harness-service`
- Section ID: `concepts/headless-harness-service#headless-harness-service`
- Rank: `12`
- Score: `1.0`

## Excerpt

A headless harness service is a UI-independent execution core that exposes harness operations through a stable protocol rather than tying them to one chat client or browser surface.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `28, 29, 30`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `28, 29, 30`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `28, 29, 30`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
