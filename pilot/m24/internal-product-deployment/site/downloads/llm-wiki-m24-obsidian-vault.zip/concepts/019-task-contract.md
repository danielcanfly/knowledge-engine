---
concept_id: "concepts/task-contract"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/task-contract#contents"
semantic_serving_enabled: false
---

# Task Contract

## Section

- Section title: Contents
- Concept ID: `concepts/task-contract`
- Section ID: `concepts/task-contract#contents`
- Rank: `19`
- Score: `1.0`

## Excerpt

The contract should name the requested result, allowed actions, forbidden mutations, required proof, acceptance criteria, budget or attempt limits, escalation conditions, and the authority that can mark the work complete.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `45, 46, 47`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `45, 46, 47`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `45, 46, 47`
- [[sources/007-m3-delivery-contract|M3 delivery contract]] citations `45, 46, 47`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
