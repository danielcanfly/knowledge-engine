---
concept_id: "concepts/task-contract"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/task-contract#contents"
semantic_serving_enabled: false
---

# Task Contract

## Section

- Section title: Contents
- Concept ID: `concepts/task-contract`
- Section ID: `concepts/task-contract#contents`
- Rank: `19`
- Score: `1.0`

## Excerpt

The contract should name the requested result, allowed actions, forbidden mutations, required proof, acceptance criteria, budget or attempt limits, escalation conditions, and the authority that can mark the work complete.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `45, 46, 47`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `45, 46, 47`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `45, 46, 47`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
