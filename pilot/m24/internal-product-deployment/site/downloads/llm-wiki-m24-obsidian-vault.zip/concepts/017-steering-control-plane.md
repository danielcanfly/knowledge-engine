---
concept_id: "concepts/steering-control-plane"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/steering-control-plane#boundary"
semantic_serving_enabled: false
---

# Steering Control Plane

## Section

- Section title: Boundary
- Concept ID: `concepts/steering-control-plane`
- Section ID: `concepts/steering-control-plane#boundary`
- Rank: `17`
- Score: `1.0`

## Excerpt

Steering is not a hidden prompt trick. It is an explicit product and governance interface for decisions that remain human-owned.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `39, 40, 41`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `39, 40, 41`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `39, 40, 41`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
