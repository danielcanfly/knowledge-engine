---
concept_id: "concepts/goal-drift"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/goal-drift#control"
semantic_serving_enabled: false
---

# Goal Drift

## Section

- Section title: Control
- Concept ID: `concepts/goal-drift`
- Section ID: `concepts/goal-drift#control`
- Rank: `7`
- Score: `1.0`

## Excerpt

Drift should be handled by re-contracting the task, recording a new decision, or stopping. It should not be hidden inside implementation details.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `13, 14, 15`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `13, 14, 15`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `13, 14, 15`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
