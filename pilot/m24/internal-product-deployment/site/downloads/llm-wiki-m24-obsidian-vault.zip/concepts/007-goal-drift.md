---
concept_id: "concepts/goal-drift"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/goal-drift#control"
semantic_serving_enabled: false
---

# Goal Drift

## Section

- Section title: Control
- Concept ID: `concepts/goal-drift`
- Section ID: `concepts/goal-drift#control`
- Rank: `7`
- Score: `1.0`

## Excerpt

Drift should be handled by re-contracting the task, recording a new decision, or stopping. It should not be hidden inside implementation details.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `13, 14, 15`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `13, 14, 15`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `13, 14, 15`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
