---
concept_id: "concepts/durable-thread-state"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/durable-thread-state#contents"
semantic_serving_enabled: false
---

# Durable Thread State

## Section

- Section title: Contents
- Concept ID: `concepts/durable-thread-state`
- Section ID: `concepts/durable-thread-state#contents`
- Rank: `6`
- Score: `1.0`

## Excerpt

The state should include thread identity, admitted task contract, current turn, outstanding decisions, tool proposals, observations, evidence pointers, progress markers, and terminal status.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `10, 11, 12`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `10, 11, 12`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `10, 11, 12`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
