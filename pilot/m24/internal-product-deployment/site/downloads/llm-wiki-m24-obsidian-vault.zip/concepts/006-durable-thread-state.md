---
concept_id: "concepts/durable-thread-state"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/durable-thread-state#contents"
semantic_serving_enabled: false
---

# Durable Thread State

## Section

- Section title: Contents
- Concept ID: `concepts/durable-thread-state`
- Section ID: `concepts/durable-thread-state#contents`
- Rank: `6`
- Score: `1.0`

## Excerpt

The state should include thread identity, admitted task contract, current turn, outstanding decisions, tool proposals, observations, evidence pointers, progress markers, and terminal status.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `10, 11, 12`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `10, 11, 12`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `10, 11, 12`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
