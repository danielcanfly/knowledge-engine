---
concept_id: "concepts/stopping-policy"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/stopping-policy#anti-loop-role"
semantic_serving_enabled: false
---

# Stopping Policy

## Section

- Section title: Anti-loop role
- Concept ID: `concepts/stopping-policy`
- Section ID: `concepts/stopping-policy#anti-loop-role`
- Rank: `18`
- Score: `1.0`

## Excerpt

A stopping policy prevents repeated observation, blind reruns, and open-ended repair loops by requiring evidence-rich attempts and a governed defer path when the current run cannot safely finish.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `42, 43, 44`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `42, 43, 44`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `42, 43, 44`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
