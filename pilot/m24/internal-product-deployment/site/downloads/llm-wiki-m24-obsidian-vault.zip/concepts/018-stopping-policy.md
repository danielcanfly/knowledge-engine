---
concept_id: "concepts/stopping-policy"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/stopping-policy#anti-loop-role"
semantic_serving_enabled: false
---

# Stopping Policy

## Section

- Section title: Anti-loop role
- Concept ID: `concepts/stopping-policy`
- Section ID: `concepts/stopping-policy#anti-loop-role`
- Rank: `18`
- Score: `1.0`

## Excerpt

A stopping policy prevents repeated observation, blind reruns, and open-ended repair loops by requiring evidence-rich attempts and a governed defer path when the current run cannot safely finish.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `42, 43, 44`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `42, 43, 44`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `42, 43, 44`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
