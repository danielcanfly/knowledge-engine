---
concept_id: "concepts/tool-call-proposal"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/tool-call-proposal#authority"
semantic_serving_enabled: false
---

# Tool Call Proposal

## Section

- Section title: Authority
- Concept ID: `concepts/tool-call-proposal`
- Section ID: `concepts/tool-call-proposal#authority`
- Rank: `20`
- Score: `1.0`

## Excerpt

A proposal should include the tool name, intended action, arguments, expected effect, risk class, and evidence or context. The harness may approve, edit, reject, defer, or require human authorization.

## Sources

- [[sources/004-proposals-m23-4-proposed-concepts-md|card_76ccff78c4920cfd5e75e05d7aaa1e43]] citations `48, 49, 50`
- [[sources/005-proposals-m23-4-provenance-summary-json|card_377f03b717782161e58d6e707704828b]] citations `48, 49, 50`
- [[sources/006-pilot-m24-m24-source-pr-19-decision-capture-json|card_7888e4d2289f0ec5ddca33d1353239e1]] citations `48, 49, 50`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
