---
concept_id: "concepts/tool-call-proposal"
raw_evidence_exposed: false
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-concept-note/v1"
section_id: "concepts/tool-call-proposal#authority"
semantic_serving_enabled: false
---

# Tool Call Proposal

## Section

- Section title: Authority
- Concept ID: `concepts/tool-call-proposal`
- Section ID: `concepts/tool-call-proposal#authority`
- Rank: `20`
- Score: `1.0`

## Excerpt

A proposal should include the tool name, intended action, arguments, expected effect, risk class, and evidence or context. The harness may approve, edit, reject, defer, or require human authorization.

## Sources

- [[sources/004-m23-4-harness-proposed-concepts-review-surface|M23.4 Harness proposed concepts review surface]] citations `48, 49, 50`
- [[sources/005-m23-4-harness-proposal-provenance-summary|M23.4 Harness proposal provenance summary]] citations `48, 49, 50`
- [[sources/006-m24-source-pr-19-human-decision-capture|M24 Source PR 19 human decision capture]] citations `48, 49, 50`

## Authority

- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Semantic promotion: `disabled`
