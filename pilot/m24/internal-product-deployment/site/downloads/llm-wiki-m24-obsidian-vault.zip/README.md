---
release_id: "20260720T160000Z-46137c97263e"
request_id: "search_b471ac35398ab7de04a4742f15ab7157"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-readme/v1"
semantic_serving_enabled: false
---

# LLM Wiki Obsidian Export

- Release ID: `20260720T160000Z-46137c97263e`
- Request ID: `search_b471ac35398ab7de04a4742f15ab7157`
- Result count: `20`
- Source viewer count: `7`
- Source document count: `7`
- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Source mutation: `not_authorized`
