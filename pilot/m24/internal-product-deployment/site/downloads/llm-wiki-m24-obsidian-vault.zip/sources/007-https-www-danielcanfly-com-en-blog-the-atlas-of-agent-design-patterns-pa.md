---
raw_evidence_exposed: false
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v1"
semantic_serving_enabled: false
source_card_id: "card_e5e02423c5d75bab8facece73fcfcef5"
source_id: "source_blog_agent_architecture_6d"
source_kind: "web"
---

# https://www.danielcanfly.com/en/blog/the-atlas-of-agent-design-patterns-part-1/

## Source

- URI: <https://www.danielcanfly.com/en/blog/the-atlas-of-agent-design-patterns-part-1/>
- Publisher: LLM Wiki Source
- Display host: `danielcanfly.com`
- Retrieved at: `2026-07-03T10:40:00Z`
- Snapshot available: `true`
- Integrity SHA-256: `not_available`

## Provenance

- Citation count: `1`
- Concept count: `1`
- Claim count: `1`
- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Raw evidence: `not_exported`

## Citations

### Citation 38

- Citation ID: `cite_e8f1b8c2a359613d2e0e0f4f7471ad09`
- Concept ID: `concepts/six-dimensional-map-of-llm-agent-architectures`
- Section ID: `concepts/six-dimensional-map-of-llm-agent-architectures#approved-claims`
- Scope: `claim`
- Support: `supporting`
- Locator: `not specified`
- Claim IDs: `claim_patterns_coexist_across_layers`
- Review status: `dec_1f9025c488e9c83356e402ec4f859d11`
- Derivation type: `human-reviewed-ai-assisted-synthesis`
