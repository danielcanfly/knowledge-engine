---
canonical_uri: "https://github.com/danielcanfly/knowledge-os-foundation"
content_bytes: 0
coverage_status: "metadata_only_with_reason"
hybrid_retrieval_enabled: false
line_count: 0
origin_blob_sha: null
origin_commit: null
origin_path: null
origin_repo: "danielcanfly/knowledge-os-foundation"
production_retrieval: "lexical"
raw_evidence_exposed: false
registry_content_sha256: null
registry_source_commit: "acf78596ace8a7366688ccef72b507204d09d9f9"
registry_source_repository: "danielcanfly/knowledge-source"
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v2"
semantic_promotion_enabled: false
semantic_serving_enabled: false
snapshot_sha256: null
source_card_id: "card_b9c636612d1fb60a4951a6a0db5f0611"
source_id: "source_m3_contract"
source_kind: "governance_contract"
source_mutation_authorized: false
write_back_authorized: false
---

# M3 delivery contract

## Source metadata

- Source ID: `source_m3_contract`
- Title: M3 delivery contract
- Canonical URI: <https://github.com/danielcanfly/knowledge-os-foundation>
- Kind: `governance_contract`
- Coverage status: `metadata_only_with_reason`
- Snapshot available: `false`
- Content bytes: `0`
- Line count: `0`

## Immutable origin identity

- Origin repo: `danielcanfly/knowledge-os-foundation`
- Origin commit: `None`
- Origin path: `None`
- Origin blob SHA: `None`

## Integrity identities

- Snapshot SHA-256: `None`
- Browser payload SHA-256: `7cf94ede7d9699bf8c8d9a5596c4759a177136689773204a37c0591c3d216f1c`
- Registry repository: `danielcanfly/knowledge-source`
- Registry SHA: `acf78596ace8a7366688ccef72b507204d09d9f9`
- Registry content SHA-256: `None`
- Registry content hash scope: `registry-declared`
- Truncated: `false`
- Executable scripts detected: `false`

## Related concepts

- [[concepts/003-candidate-delivery-controls|Candidate delivery controls]]
- [[concepts/005-completion-gate|Completion Gate]]
- [[concepts/014-knowledge-source-governance|Knowledge source governance]]
- [[concepts/019-task-contract|Task Contract]]

## Full source content

- Coverage: `metadata_only_with_reason`
- Reason: No exact release-authoritative file or immutable snapshot was resolved for this governance contract in the M24.14.5 repair authority boundary.
- Raw evidence: `metadata_only_exact_reason_preserved`

## Citation ledger

### Citation 3

- Citation ID: `cite_c27f20ede994b1ca98f229a1c7a3a7f8`
- Concept ID: [[concepts/003-candidate-delivery-controls|Candidate delivery controls]]
- Section ID: `concepts/candidate-delivery-controls#candidate-delivery-controls`
- Scope: `concept`
- Support: `supporting`
- Locator: `not specified`

### Citation 34

- Citation ID: `cite_f3284f3b48994f75de5c8660ccf80fee`
- Concept ID: [[concepts/014-knowledge-source-governance|Knowledge source governance]]
- Section ID: `concepts/source-governance#knowledge-source-governance`
- Scope: `concept`
- Support: `supporting`
- Locator: `not specified`
- Derivation type: `manual_review`
