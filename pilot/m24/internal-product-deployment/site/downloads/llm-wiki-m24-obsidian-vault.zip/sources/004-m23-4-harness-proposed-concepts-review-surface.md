---
canonical_uri: "https://github.com/danielcanfly/knowledge-source/blob/deb3ad1e631c2149183d10561fbceb0a1848a989/proposals/m23-4/proposed-concepts.md"
content_bytes: 5066
coverage_status: "full_snapshot"
hybrid_retrieval_enabled: false
line_count: 133
origin_blob_sha: "bdfdc26610f38e89869241194cab7bb1b700a6d1"
origin_commit: "deb3ad1e631c2149183d10561fbceb0a1848a989"
origin_path: "proposals/m23-4/proposed-concepts.md"
origin_repo: "danielcanfly/knowledge-source"
production_retrieval: "lexical"
raw_evidence_exposed: false
registry_content_sha256: "1e580018c29fae0e07c66d39acdf09adc675b535a85153129130a8211189e4c4"
registry_source_commit: "acf78596ace8a7366688ccef72b507204d09d9f9"
registry_source_repository: "danielcanfly/knowledge-source"
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v2"
semantic_promotion_enabled: false
semantic_serving_enabled: false
snapshot_sha256: "1e580018c29fae0e07c66d39acdf09adc675b535a85153129130a8211189e4c4"
source_card_id: "card_76ccff78c4920cfd5e75e05d7aaa1e43"
source_id: "source_m23_4_harness_proposed_concepts"
source_kind: "markdown"
source_mutation_authorized: false
write_back_authorized: false
---

# M23.4 Harness proposed concepts review surface

## Source metadata

- Source ID: `source_m23_4_harness_proposed_concepts`
- Title: M23.4 Harness proposed concepts review surface
- Canonical URI: <https://github.com/danielcanfly/knowledge-source/blob/deb3ad1e631c2149183d10561fbceb0a1848a989/proposals/m23-4/proposed-concepts.md>
- Kind: `markdown`
- Coverage status: `full_snapshot`
- Snapshot available: `true`
- Content bytes: `5066`
- Line count: `133`

## Immutable origin identity

- Origin repo: `danielcanfly/knowledge-source`
- Origin commit: `deb3ad1e631c2149183d10561fbceb0a1848a989`
- Origin path: `proposals/m23-4/proposed-concepts.md`
- Origin blob SHA: `bdfdc26610f38e89869241194cab7bb1b700a6d1`

## Integrity identities

- Snapshot SHA-256: `1e580018c29fae0e07c66d39acdf09adc675b535a85153129130a8211189e4c4`
- Browser payload SHA-256: `e45e59da86562ec5f654c3b746df119491fe030613a515153fc61eca50a049fe`
- Registry repository: `danielcanfly/knowledge-source`
- Registry SHA: `acf78596ace8a7366688ccef72b507204d09d9f9`
- Registry content SHA-256: `1e580018c29fae0e07c66d39acdf09adc675b535a85153129130a8211189e4c4`
- Registry content hash scope: `source-pr-review-surface-file`
- Truncated: `false`
- Executable scripts detected: `false`

## Related concepts

- [[concepts/004-canonical-run-authority|Canonical Run Authority]]
- [[concepts/005-completion-gate|Completion Gate]]
- [[concepts/006-durable-thread-state|Durable Thread State]]
- [[concepts/007-goal-drift|Goal Drift]]
- [[concepts/008-harness|Harness]]
- [[concepts/009-harness-agent-loop|Harness Agent Loop]]
- [[concepts/010-harness-verification|Harness Verification]]
- [[concepts/011-harnessability|Harnessability]]
- [[concepts/012-headless-harness-service|Headless Harness Service]]
- [[concepts/013-item-turn-thread-protocol|Item Turn Thread Protocol]]
- [[concepts/015-request-boundary|Request Boundary]]
- [[concepts/017-steering-control-plane|Steering Control Plane]]
- [[concepts/018-stopping-policy|Stopping Policy]]
- [[concepts/019-task-contract|Task Contract]]
- [[concepts/020-tool-call-proposal|Tool Call Proposal]]

## Full source content

<!-- full native Markdown snapshot begins -->

# M23.4 proposed concepts

> Review-only. Not canonical.

## Agent Loop

**Proposed definition:** A governed state machine coordinating model proposals, authorisation, tool execution, observations and termination.

- tags: `agents`, `runtime`
- relationships: supports Harness; contains Tool Calling; requires Stopping Policy; supported by Item Turn Thread Protocol
- attachment: bilingual term Agent Loop
- resolution: `probable_duplicate` from shared governed tags only

## Canonical Run Authority

**Proposed definition:** The system of record that owns authoritative execution state and transitions.

- tags: `governance`, `runtime`, `reliability`
- relationship: part of Harness
- attachment: Architecture review begins with authority
- resolution: `probable_duplicate` from shared governed tags only

## Completion Gate

**Proposed definition:** The authority that accepts or rejects a terminal candidate against contract and evidence.

- tags: `verification`, `reliability`
- relationship: part of Harness
- attachment: bilingual term Completion Gate
- resolution: `probable_duplicate` from shared governed tags only

## Durable Thread State

**Proposed definition:** Persistent interaction state that survives client disconnects and spans turns.

- tags: `runtime`, `reliability`
- relationship: supports Headless Harness Service
- resolution: `probable_duplicate` from shared governed tags only

## Goal Drift

**Proposed definition:** Uncontrolled movement away from the accepted task contract or authorised change process.

- tags: `governance`, `reliability`
- relationship: related to Task Contract
- resolution: `probable_duplicate` from shared governed tags only

## Harness

**Proposed definition:** The execution and governance system around an LLM or agent runtime.

- tags: `agents`, `governance`, `runtime`
- relationships: contains Request Boundary, Task Contract, Completion Gate and Canonical Run Authority; supports Agent Loop; requires Verification; implemented by Headless Harness Service
- attachments: Agent Harness alias; Harness responsibility boundary claim; Harness working definition; bilingual Harness term
- resolution: `probable_duplicate` from shared governed tags only

## Harnessability

**Proposed definition:** The degree to which an environment makes agent work bounded, legible, verifiable and recoverable.

- tags: `reliability`, `design`, `agents`
- resolution: `probable_duplicate` from shared governed tags only

## Headless Harness Service

**Proposed definition:** A UI-independent execution core shared by multiple clients through a stable protocol.

- tags: `runtime`, `agents`
- relationships: implements Harness; supported by Durable Thread State
- resolution: `probable_duplicate` from shared governed tags only

## Item Turn Thread Protocol

**Proposed definition:** A protocol model separating typed interaction items, pausable work turns and durable threads.

- tags: `runtime`, `agents`
- relationship: supports Agent Loop
- resolution: `probable_duplicate` from shared governed tags only

## Request Boundary

**Proposed definition:** The ingress layer that establishes identity, tenant scope, schema validity and admission.

- tags: `security`, `design`
- relationship: part of Harness
- attachment: bilingual Request Boundary term
- resolution: `probable_duplicate` from shared governed tags only

## Steering Control Plane

**Proposed definition:** The human authority layer that sets intent, boundaries, evidence requirements and escalation rules.

- tags: `design`, `governance`
- attachment: bilingual term 控制平面
- resolution: `probable_duplicate` from shared governed tags only

## Stopping Policy

**Proposed definition:** Rules that decide whether execution continues, waits, completes, fails or is cancelled.

- tags: `governance`, `reliability`, `runtime`
- relationship: required by Agent Loop
- attachment: bilingual term Stop Policy
- resolution: `probable_duplicate` from shared governed tags only

## Task Contract

**Proposed definition:** The explicit statement of required outcome, constraints, evidence and completion conditions.

- tags: `design`, `governance`
- relationships: part of Harness; related to Goal Drift
- resolution: `probable_duplicate` from shared governed tags only

## Tool Calling

**Proposed definition:** A structured interface through which a model proposes an external operation.

- tags: `agents`, `runtime`
- relationship: part of Agent Loop
- attachment: Tool calls are proposals claim
- resolution: `probable_duplicate` from shared governed tags only

## Verification

**Proposed definition:** External checks that determine whether an agent result or side effect should be accepted.

- tags: `reliability`, `verification`
- relationship: required by Harness
- resolution: `probable_duplicate` from shared governed tags only

## Human decision required

Each section requires one explicit decision: `approve_new`, `map_existing`, `edit`, `reject`, or `defer`. No proposal in this file is canonical knowledge, and the draft PR must not be merged as-is.

<!-- full native Markdown snapshot ends -->

## Citation ledger

### Citation 4

- Citation ID: `cite_a30bc67b65f675f7e8fc49894db73279`
- Concept ID: [[concepts/004-canonical-run-authority|Canonical Run Authority]]
- Section ID: `concepts/canonical-run-authority#canonical-run-authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3942-3965`
- Claim IDs: `claim_canonical_run_authority_definition`
- Review status: `m23review_8566693dd5241e3269f5038e01394f6b`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 7

- Citation ID: `cite_0b5b5e93e4aecd5afe0e177adedd2a87`
- Concept ID: [[concepts/005-completion-gate|Completion Gate]]
- Section ID: `concepts/completion-gate#authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:4397-4412`
- Claim IDs: `claim_completion_gate_definition`
- Review status: `m23review_ed53fb63ef649af90d2e2f73e85ae5e7`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 10

- Citation ID: `cite_57ee964d2ebb615a8e86e241886e5670`
- Concept ID: [[concepts/006-durable-thread-state|Durable Thread State]]
- Section ID: `concepts/durable-thread-state#contents`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:21567-21587`
- Claim IDs: `claim_durable_thread_state_definition`
- Review status: `m23review_ce9255a1a87d7f2cc87c88ec26e1dc9a`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 13

- Citation ID: `cite_99c08c811e0b5fcbea75b66374281299`
- Concept ID: [[concepts/007-goal-drift|Goal Drift]]
- Section ID: `concepts/goal-drift#control`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:21654-21709`
- Claim IDs: `claim_goal_drift_definition`
- Review status: `m23review_0df0b6cb698712b98425cc2b05265565`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 16

- Citation ID: `cite_d8c5c49a2a53626d014a51d1c82f6297`
- Concept ID: [[concepts/008-harness|Harness]]
- Section ID: `concepts/harness#boundary`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:1805-1882`
- Claim IDs: `claim_harness_definition`
- Review status: `m23review_e2847c567565549ea21b89ee7b572d47`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 19

- Citation ID: `cite_3ff85fb56f83e438f7dd4ca97377c79f`
- Concept ID: [[concepts/009-harness-agent-loop|Harness Agent Loop]]
- Section ID: `concepts/harness-agent-loop#control`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:37-65`
- Claim IDs: `claim_harness_agent_loop_definition`
- Review status: `m23review_998e1adb9a6ce64f12a4fc9477eebe30`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 22

- Citation ID: `cite_3e2655a44fcd26ac692e20d4849cca28`
- Concept ID: [[concepts/010-harness-verification|Harness Verification]]
- Section ID: `concepts/harness-verification#edited-adoption`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:1731-1743`
- Claim IDs: `claim_harness_verification_definition`
- Review status: `m23review_a91d9910fbd95236a02e5f1bf52a1b27`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 25

- Citation ID: `cite_c1b8099f276cd505bc1c947aa1dd632f`
- Concept ID: [[concepts/011-harnessability|Harnessability]]
- Section ID: `concepts/harnessability#assessment`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:13909-13923`
- Claim IDs: `claim_harnessability_definition`
- Review status: `m23review_94192ccc4b53c47e32942121da3775c2`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 28

- Citation ID: `cite_ee689e97ebb9eef962966a11e993dddf`
- Concept ID: [[concepts/012-headless-harness-service|Headless Harness Service]]
- Section ID: `concepts/headless-harness-service#headless-harness-service`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:20344-20368`
- Claim IDs: `claim_headless_harness_service_definition`
- Review status: `m23review_ee3af10c8e0f2f6d9fb49c6c7b1f308c`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 31

- Citation ID: `cite_b73b27cb1ab26be2a8f5dc289f197c6a`
- Concept ID: [[concepts/013-item-turn-thread-protocol|Item Turn Thread Protocol]]
- Section ID: `concepts/item-turn-thread-protocol#item-turn-thread-protocol`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:16100-16158`
- Claim IDs: `claim_item_turn_thread_protocol_definition`
- Review status: `m23review_08f2083f1643842c7266a7fa3e7118b1`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 35

- Citation ID: `cite_b1ccb63577f6545bc214be03e71396e8`
- Concept ID: [[concepts/015-request-boundary|Request Boundary]]
- Section ID: `concepts/request-boundary#admission-checks`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3778-3794`
- Claim IDs: `claim_request_boundary_definition`
- Review status: `m23review_12cf0442aff36f0400715efe1ee1025a`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 39

- Citation ID: `cite_e71bec028e5ed455f3769195b681b5c9`
- Concept ID: [[concepts/017-steering-control-plane|Steering Control Plane]]
- Section ID: `concepts/steering-control-plane#boundary`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:214-236`
- Claim IDs: `claim_steering_control_plane_definition`
- Review status: `m23review_784ebc246b86b22be547d2f4c006ca64`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 42

- Citation ID: `cite_9434fae5f31093a50b61e5ec65fc3a89`
- Concept ID: [[concepts/018-stopping-policy|Stopping Policy]]
- Section ID: `concepts/stopping-policy#anti-loop-role`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:20305-20377`
- Claim IDs: `claim_stopping_policy_definition`
- Review status: `m23review_7c7842b8a5e71c5f7577b26c27e2f73f`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 45

- Citation ID: `cite_913be81bbde6b657f9e3573ef0a0f81e`
- Concept ID: [[concepts/019-task-contract|Task Contract]]
- Section ID: `concepts/task-contract#contents`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3846-3859`
- Claim IDs: `claim_task_contract_definition`
- Review status: `m23review_37d35397ace98d69c00b0e8fe4cb1458`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 48

- Citation ID: `cite_4ae61cc7f1f64afd5c01df3f45d0318f`
- Concept ID: [[concepts/020-tool-call-proposal|Tool Call Proposal]]
- Section ID: `concepts/tool-call-proposal#authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:2155-2222`
- Claim IDs: `claim_tool_call_proposal_definition`
- Review status: `m23review_c3b0082d594d591018a417614574b098`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`
