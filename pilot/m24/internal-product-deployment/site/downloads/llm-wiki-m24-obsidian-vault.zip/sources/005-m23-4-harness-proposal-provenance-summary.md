---
canonical_uri: "https://github.com/danielcanfly/knowledge-source/blob/deb3ad1e631c2149183d10561fbceb0a1848a989/proposals/m23-4/provenance-summary.json"
content_bytes: 4434
coverage_status: "structured_snapshot"
hybrid_retrieval_enabled: false
line_count: 23
origin_blob_sha: "15ef0ed616f93b618adcf6f7a4abf3eba9af9cea"
origin_commit: "deb3ad1e631c2149183d10561fbceb0a1848a989"
origin_path: "proposals/m23-4/provenance-summary.json"
origin_repo: "danielcanfly/knowledge-source"
production_retrieval: "lexical"
raw_evidence_exposed: false
registry_content_sha256: "873844b75fc5cbfd2f55a20321461abce0e2de2ada4137eade56acf1cd9b8c57"
registry_source_commit: "acf78596ace8a7366688ccef72b507204d09d9f9"
registry_source_repository: "danielcanfly/knowledge-source"
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v2"
semantic_promotion_enabled: false
semantic_serving_enabled: false
snapshot_sha256: "873844b75fc5cbfd2f55a20321461abce0e2de2ada4137eade56acf1cd9b8c57"
source_card_id: "card_377f03b717782161e58d6e707704828b"
source_id: "source_m23_4_harness_provenance_summary"
source_kind: "json"
source_mutation_authorized: false
write_back_authorized: false
---

# M23.4 Harness proposal provenance summary

## Source metadata

- Source ID: `source_m23_4_harness_provenance_summary`
- Title: M23.4 Harness proposal provenance summary
- Canonical URI: <https://github.com/danielcanfly/knowledge-source/blob/deb3ad1e631c2149183d10561fbceb0a1848a989/proposals/m23-4/provenance-summary.json>
- Kind: `json`
- Coverage status: `structured_snapshot`
- Snapshot available: `true`
- Content bytes: `4434`
- Line count: `23`

## Immutable origin identity

- Origin repo: `danielcanfly/knowledge-source`
- Origin commit: `deb3ad1e631c2149183d10561fbceb0a1848a989`
- Origin path: `proposals/m23-4/provenance-summary.json`
- Origin blob SHA: `15ef0ed616f93b618adcf6f7a4abf3eba9af9cea`

## Integrity identities

- Snapshot SHA-256: `873844b75fc5cbfd2f55a20321461abce0e2de2ada4137eade56acf1cd9b8c57`
- Browser payload SHA-256: `c9a6da0252fee27033bed294ffd22617de2130f4fa2ecd996385ea44b72cc46f`
- Registry repository: `danielcanfly/knowledge-source`
- Registry SHA: `acf78596ace8a7366688ccef72b507204d09d9f9`
- Registry content SHA-256: `873844b75fc5cbfd2f55a20321461abce0e2de2ada4137eade56acf1cd9b8c57`
- Registry content hash scope: `source-pr-review-surface-file`
- Truncated: `false`
- Executable scripts detected: `false`

## Related concepts

- [[concepts/004-canonical-run-authority|Canonical Run Authority]]
- [[concepts/005-completion-gate|Completion Gate]]
- [[concepts/006-durable-thread-state|Durable Thread State]]
- [[concepts/007-goal-drift|Goal Drift]]
- [[concepts/008-harness|Harness]]
- [[concepts/009-harness-agent-loop|Harness Agent Loop]]
- [[concepts/010-harness-verification|Harness Verification]]
- [[concepts/011-harnessability|Harnessability]]
- [[concepts/012-headless-harness-service|Headless Harness Service]]
- [[concepts/013-item-turn-thread-protocol|Item Turn Thread Protocol]]
- [[concepts/015-request-boundary|Request Boundary]]
- [[concepts/017-steering-control-plane|Steering Control Plane]]
- [[concepts/018-stopping-policy|Stopping Policy]]
- [[concepts/019-task-contract|Task Contract]]
- [[concepts/020-tool-call-proposal|Tool Call Proposal]]

## Full source content

```json
{
  "bundle_sha256": "e65fdb2d563e2bac04cac04e4844e15ebf7db3f81429781570f177a575922d2b",
  "canonical_write_permitted": false,
  "extraction_packet_sha256": "32f29be6fa4a90d6495b0844fbe0e8a2003dec25d3adf5328a0fd0b2232ce402",
  "records": [
    {"candidate_id":"conceptcand_225a9ee65ca6ef67c5d6015d7f4e0cb3","evidence":[{"derivative_id":"derivative_harness-theory-part-02-en","end":20368,"excerpt_sha256":"28f99faaff1fd0537e9f48e27b96de2684d030fc3448fc4b5129b1f6980e8b19","start":20344}],"label":"Headless Harness Service"},
    {"candidate_id":"conceptcand_632f23ba5b420f1403631d38bd2f4e10","evidence":[{"derivative_id":"derivative_harness-theory-part-02-en","end":3794,"excerpt_sha256":"6dd0a2e7c8eba56b4f11045a82145003853e46a8768b1663755c449f6bfb4afa","start":3778}],"label":"Request Boundary"},
    {"candidate_id":"conceptcand_674327c38116ba67829aa0e92480f906","evidence":[{"derivative_id":"derivative_harness-theory-part-01-en","end":13923,"excerpt_sha256":"37298e371d06f25241518585aadfa4c00203b3e29cc6b38298df8ec5eee522ef","start":13909}],"label":"Harnessability"},
    {"candidate_id":"conceptcand_724ab01fa724799d46ddb2b9497d7752","evidence":[{"derivative_id":"derivative_harness-theory-part-02-en","end":4412,"excerpt_sha256":"7b71223b2dcaa62db1ec3b0f5cb24f3fef57d6fae30f0605c68a392c056b3a41","start":4397}],"label":"Completion Gate"},
    {"candidate_id":"conceptcand_8a73560fa206f8d5d9323e648d15d2c0","evidence":[{"derivative_id":"derivative_harness-theory-part-03-en","end":20377,"excerpt_sha256":"45ea9a9da8fde3a61165cbe88eb4103cbdc78831101cefe0ed622fa2f10e749a","start":20305}],"label":"Stopping Policy"},
    {"candidate_id":"conceptcand_a857949159ff2af3a917b9b4945d2563","evidence":[{"derivative_id":"derivative_harness-theory-part-03-en","end":65,"excerpt_sha256":"52a65b6cf105b50ac02376bc0b84c222bed5b0cf4a758040fb5857569fc1cc3e","start":37}],"label":"Agent Loop"},
    {"candidate_id":"conceptcand_bd10b1c1b28edb6e20d34b96c780c10a","evidence":[{"derivative_id":"derivative_harness-theory-part-02-en","end":3965,"excerpt_sha256":"2e35375f9fa40589b29ddc47ad99a5b345950a6ac498573c4e44597bd05eb768","start":3942}],"label":"Canonical Run Authority"},
    {"candidate_id":"conceptcand_c574aa8a041d990b0848426332cbe695","evidence":[{"derivative_id":"derivative_harness-theory-part-01-en","end":1882,"excerpt_sha256":"d136d700e646065e934f6ebe13d828ccf747945a579ace0754dd5fcd1ba1a9dc","start":1805}],"label":"Harness"},
    {"candidate_id":"conceptcand_cce3e198ea0f2ca4a2394e8c97e63826","evidence":[{"derivative_id":"derivative_harness-theory-part-03-en","end":2222,"excerpt_sha256":"615a974ea4617c125cf4e2a292e13c1c73d8978eee92d5d8db5172df45edcafd","start":2155}],"label":"Tool Calling"},
    {"candidate_id":"conceptcand_d3d6dd0bc39b6d17ac3f77830f59a8e4","evidence":[{"derivative_id":"derivative_harness-theory-part-03-en","end":21709,"excerpt_sha256":"576e3df3645809b5ac0050af75761ad507a562f46e42bfe86b93b3b32e3f0ff4","start":21654}],"label":"Goal Drift"},
    {"candidate_id":"conceptcand_dae13dfab2f3bd99933996727ae31785","evidence":[{"derivative_id":"derivative_harness-theory-part-01-en","end":1743,"excerpt_sha256":"4183b7793fd28ba47ea9e79e7697f2915da218567e6657a158b51bd14bce91cd","start":1731}],"label":"Verification"},
    {"candidate_id":"conceptcand_dcc0a2165404ede003499acbc175bc91","evidence":[{"derivative_id":"derivative_harness-theory-part-03-en","end":16158,"excerpt_sha256":"7abfe83662569f15f7862107ea875e2024c465fd411ecaa4c3aaa7651768c18a","start":16100}],"label":"Item Turn Thread Protocol"},
    {"candidate_id":"conceptcand_dfae712de3eb869423e8f6a4ddc1007e","evidence":[{"derivative_id":"derivative_harness-theory-part-01-en","end":236,"excerpt_sha256":"6c1a9bac3918c703c21849c34b05bdc5956b3d7adc98bc165a77d14aec8680a0","start":214}],"label":"Steering Control Plane"},
    {"candidate_id":"conceptcand_e9cb685f0b06f9b488b327f1b05ba4bb","evidence":[{"derivative_id":"derivative_harness-theory-part-02-en","end":3859,"excerpt_sha256":"f17e312ac6bd8ae16092c4d66df8079986e7587f636be5aa7e01f53805bceabd","start":3846}],"label":"Task Contract"},
    {"candidate_id":"conceptcand_fe165e95fd7459e5a6f1cd1a7d418c25","evidence":[{"derivative_id":"derivative_harness-theory-part-02-en","end":21587,"excerpt_sha256":"e7b041efc701cb600b0fac60b1d9c7cee93b3ae989d6e72c137f8f654bf65a46","start":21567}],"label":"Durable Thread State"}
  ],
  "schema_version": "knowledge-source-m23-proposal-provenance-summary/v1"
}
```

## Citation ledger

### Citation 5

- Citation ID: `cite_93eba9c15da6041a0537b16b342c6c32`
- Concept ID: [[concepts/004-canonical-run-authority|Canonical Run Authority]]
- Section ID: `concepts/canonical-run-authority#canonical-run-authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3942-3965`
- Claim IDs: `claim_canonical_run_authority_definition`
- Review status: `m23review_8566693dd5241e3269f5038e01394f6b`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 8

- Citation ID: `cite_048db1c8f143254c0bb2765e8ae1aba5`
- Concept ID: [[concepts/005-completion-gate|Completion Gate]]
- Section ID: `concepts/completion-gate#authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:4397-4412`
- Claim IDs: `claim_completion_gate_definition`
- Review status: `m23review_ed53fb63ef649af90d2e2f73e85ae5e7`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 11

- Citation ID: `cite_9b55d68356b403f73a28f4631de54369`
- Concept ID: [[concepts/006-durable-thread-state|Durable Thread State]]
- Section ID: `concepts/durable-thread-state#contents`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:21567-21587`
- Claim IDs: `claim_durable_thread_state_definition`
- Review status: `m23review_ce9255a1a87d7f2cc87c88ec26e1dc9a`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 14

- Citation ID: `cite_dcefb58b38e3d5faf9141af561e30236`
- Concept ID: [[concepts/007-goal-drift|Goal Drift]]
- Section ID: `concepts/goal-drift#control`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:21654-21709`
- Claim IDs: `claim_goal_drift_definition`
- Review status: `m23review_0df0b6cb698712b98425cc2b05265565`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 17

- Citation ID: `cite_7c47ba18799bd39a46d1f4297ce4cef9`
- Concept ID: [[concepts/008-harness|Harness]]
- Section ID: `concepts/harness#boundary`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:1805-1882`
- Claim IDs: `claim_harness_definition`
- Review status: `m23review_e2847c567565549ea21b89ee7b572d47`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 20

- Citation ID: `cite_7a1db871455972f3d23a8347b48b0178`
- Concept ID: [[concepts/009-harness-agent-loop|Harness Agent Loop]]
- Section ID: `concepts/harness-agent-loop#control`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:37-65`
- Claim IDs: `claim_harness_agent_loop_definition`
- Review status: `m23review_998e1adb9a6ce64f12a4fc9477eebe30`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 23

- Citation ID: `cite_11d2e20f4f5d4150a58b83996c96a4de`
- Concept ID: [[concepts/010-harness-verification|Harness Verification]]
- Section ID: `concepts/harness-verification#edited-adoption`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:1731-1743`
- Claim IDs: `claim_harness_verification_definition`
- Review status: `m23review_a91d9910fbd95236a02e5f1bf52a1b27`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 26

- Citation ID: `cite_60ef65830021f521b81fd4df6b52b60f`
- Concept ID: [[concepts/011-harnessability|Harnessability]]
- Section ID: `concepts/harnessability#assessment`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:13909-13923`
- Claim IDs: `claim_harnessability_definition`
- Review status: `m23review_94192ccc4b53c47e32942121da3775c2`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 29

- Citation ID: `cite_7f0020696f493568ab2f8a39b1858cf1`
- Concept ID: [[concepts/012-headless-harness-service|Headless Harness Service]]
- Section ID: `concepts/headless-harness-service#headless-harness-service`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:20344-20368`
- Claim IDs: `claim_headless_harness_service_definition`
- Review status: `m23review_ee3af10c8e0f2f6d9fb49c6c7b1f308c`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 32

- Citation ID: `cite_f43cd410257bceb1a3c3100363596b89`
- Concept ID: [[concepts/013-item-turn-thread-protocol|Item Turn Thread Protocol]]
- Section ID: `concepts/item-turn-thread-protocol#item-turn-thread-protocol`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:16100-16158`
- Claim IDs: `claim_item_turn_thread_protocol_definition`
- Review status: `m23review_08f2083f1643842c7266a7fa3e7118b1`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 36

- Citation ID: `cite_2eb25c2eab8bda1841753ef9ceffda78`
- Concept ID: [[concepts/015-request-boundary|Request Boundary]]
- Section ID: `concepts/request-boundary#admission-checks`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3778-3794`
- Claim IDs: `claim_request_boundary_definition`
- Review status: `m23review_12cf0442aff36f0400715efe1ee1025a`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 40

- Citation ID: `cite_fcec5b8246f88380568860bcc1c65f41`
- Concept ID: [[concepts/017-steering-control-plane|Steering Control Plane]]
- Section ID: `concepts/steering-control-plane#boundary`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:214-236`
- Claim IDs: `claim_steering_control_plane_definition`
- Review status: `m23review_784ebc246b86b22be547d2f4c006ca64`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 43

- Citation ID: `cite_10c81cc1ed9af839204021b9c610c5e7`
- Concept ID: [[concepts/018-stopping-policy|Stopping Policy]]
- Section ID: `concepts/stopping-policy#anti-loop-role`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:20305-20377`
- Claim IDs: `claim_stopping_policy_definition`
- Review status: `m23review_7c7842b8a5e71c5f7577b26c27e2f73f`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 46

- Citation ID: `cite_59a853a618f0278822710d789f7d5e63`
- Concept ID: [[concepts/019-task-contract|Task Contract]]
- Section ID: `concepts/task-contract#contents`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3846-3859`
- Claim IDs: `claim_task_contract_definition`
- Review status: `m23review_37d35397ace98d69c00b0e8fe4cb1458`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 49

- Citation ID: `cite_1ed73fbcf300891f3266b962b68301ff`
- Concept ID: [[concepts/020-tool-call-proposal|Tool Call Proposal]]
- Section ID: `concepts/tool-call-proposal#authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:2155-2222`
- Claim IDs: `claim_tool_call_proposal_definition`
- Review status: `m23review_c3b0082d594d591018a417614574b098`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`
