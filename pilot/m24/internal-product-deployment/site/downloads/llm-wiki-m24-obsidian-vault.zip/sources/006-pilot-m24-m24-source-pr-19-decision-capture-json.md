---
raw_evidence_exposed: false
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v1"
semantic_serving_enabled: false
source_card_id: "card_7888e4d2289f0ec5ddca33d1353239e1"
source_id: "source_m24_source_pr_19_decision_capture"
source_kind: "web"
---

# pilot/m24/m24-source-pr-19-decision-capture.json

## Source

- URI: <https://github.com/danielcanfly/knowledge-engine/blob/22041bfecd07c9e4b75146ab4d0b83e417e914e8/pilot/m24/m24-source-pr-19-decision-capture.json>
- Publisher: LLM Wiki Source
- Display host: `github.com`
- Retrieved at: `2026-07-20T09:11:44Z`
- Snapshot available: `true`
- Integrity SHA-256: `not_available`

## Provenance

- Citation count: `15`
- Concept count: `15`
- Claim count: `15`
- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Raw evidence: `not_exported`

## Citations

### Citation 6

- Citation ID: `cite_a93d472b38713c27214580a9b5e30836`
- Concept ID: `concepts/canonical-run-authority`
- Section ID: `concepts/canonical-run-authority#canonical-run-authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3942-3965`
- Claim IDs: `claim_canonical_run_authority_definition`
- Review status: `m23review_8566693dd5241e3269f5038e01394f6b`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 9

- Citation ID: `cite_3c518c98a9130dae6e53c6f69b41d45e`
- Concept ID: `concepts/completion-gate`
- Section ID: `concepts/completion-gate#authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:4397-4412`
- Claim IDs: `claim_completion_gate_definition`
- Review status: `m23review_ed53fb63ef649af90d2e2f73e85ae5e7`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 12

- Citation ID: `cite_ca6d70eb83b8f5b7fd630fa2c361abbe`
- Concept ID: `concepts/durable-thread-state`
- Section ID: `concepts/durable-thread-state#contents`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:21567-21587`
- Claim IDs: `claim_durable_thread_state_definition`
- Review status: `m23review_ce9255a1a87d7f2cc87c88ec26e1dc9a`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 15

- Citation ID: `cite_3fcc77d9898fdb6d1e08b0d9cf828fb5`
- Concept ID: `concepts/goal-drift`
- Section ID: `concepts/goal-drift#control`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:21654-21709`
- Claim IDs: `claim_goal_drift_definition`
- Review status: `m23review_0df0b6cb698712b98425cc2b05265565`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 18

- Citation ID: `cite_ba7f062d1db96ba9391590a2aaf4469b`
- Concept ID: `concepts/harness`
- Section ID: `concepts/harness#boundary`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:1805-1882`
- Claim IDs: `claim_harness_definition`
- Review status: `m23review_e2847c567565549ea21b89ee7b572d47`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 21

- Citation ID: `cite_d03da5cfd6a7694bc620bb68d57f8a18`
- Concept ID: `concepts/harness-agent-loop`
- Section ID: `concepts/harness-agent-loop#control`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:37-65`
- Claim IDs: `claim_harness_agent_loop_definition`
- Review status: `m23review_998e1adb9a6ce64f12a4fc9477eebe30`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 24

- Citation ID: `cite_bd29243f7dc1211cfb3e09e0097b00b4`
- Concept ID: `concepts/harness-verification`
- Section ID: `concepts/harness-verification#edited-adoption`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:1731-1743`
- Claim IDs: `claim_harness_verification_definition`
- Review status: `m23review_a91d9910fbd95236a02e5f1bf52a1b27`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 27

- Citation ID: `cite_a2ab84136992b93b3d893c5f51f0953b`
- Concept ID: `concepts/harnessability`
- Section ID: `concepts/harnessability#assessment`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:13909-13923`
- Claim IDs: `claim_harnessability_definition`
- Review status: `m23review_94192ccc4b53c47e32942121da3775c2`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 30

- Citation ID: `cite_e9bed7cd33ec7c13ca36cf2106cd4ca9`
- Concept ID: `concepts/headless-harness-service`
- Section ID: `concepts/headless-harness-service#headless-harness-service`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:20344-20368`
- Claim IDs: `claim_headless_harness_service_definition`
- Review status: `m23review_ee3af10c8e0f2f6d9fb49c6c7b1f308c`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 33

- Citation ID: `cite_4b4ac17f7297fac16a1b64d87970f980`
- Concept ID: `concepts/item-turn-thread-protocol`
- Section ID: `concepts/item-turn-thread-protocol#item-turn-thread-protocol`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:16100-16158`
- Claim IDs: `claim_item_turn_thread_protocol_definition`
- Review status: `m23review_08f2083f1643842c7266a7fa3e7118b1`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 37

- Citation ID: `cite_0220ce500eb84c2f2ed41ceed280c2a8`
- Concept ID: `concepts/request-boundary`
- Section ID: `concepts/request-boundary#admission-checks`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3778-3794`
- Claim IDs: `claim_request_boundary_definition`
- Review status: `m23review_12cf0442aff36f0400715efe1ee1025a`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 41

- Citation ID: `cite_e698236708598c34398317e88fde4e00`
- Concept ID: `concepts/steering-control-plane`
- Section ID: `concepts/steering-control-plane#boundary`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-01-en:214-236`
- Claim IDs: `claim_steering_control_plane_definition`
- Review status: `m23review_784ebc246b86b22be547d2f4c006ca64`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 44

- Citation ID: `cite_88cd1b66e94281909a9547fbd39c41fd`
- Concept ID: `concepts/stopping-policy`
- Section ID: `concepts/stopping-policy#anti-loop-role`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:20305-20377`
- Claim IDs: `claim_stopping_policy_definition`
- Review status: `m23review_7c7842b8a5e71c5f7577b26c27e2f73f`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 47

- Citation ID: `cite_908997feb56338de27af55040abeeaa6`
- Concept ID: `concepts/task-contract`
- Section ID: `concepts/task-contract#contents`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-02-en:3846-3859`
- Claim IDs: `claim_task_contract_definition`
- Review status: `m23review_37d35397ace98d69c00b0e8fe4cb1458`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`

### Citation 50

- Citation ID: `cite_f9dfa199bf54ab497633b5d5e8a2390b`
- Concept ID: `concepts/tool-call-proposal`
- Section ID: `concepts/tool-call-proposal#authority`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=derivative_harness-theory-part-03-en:2155-2222`
- Claim IDs: `claim_tool_call_proposal_definition`
- Review status: `m23review_c3b0082d594d591018a417614574b098`
- Derivation type: `human-reviewed-ai-assisted-source-adoption`
