---
raw_evidence_exposed: false
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v1"
semantic_serving_enabled: false
source_card_id: "card_784b4fdd68d221c2ecc7a82fbccd790c"
source_id: "source_blog_agent_execution_paths"
source_kind: "web"
---

# src/content/blog/the-atlas-of-agent-design-patterns-part-2/en.md

## Source

- URI: <https://www.danielcanfly.com/en/blog/the-atlas-of-agent-design-patterns-part-2/>
- Publisher: LLM Wiki Source
- Display host: `danielcanfly.com`
- Retrieved at: `2026-07-07T10:32:36Z`
- Snapshot available: `true`
- Integrity SHA-256: `not_available`

## Provenance

- Citation count: `1`
- Concept count: `1`
- Claim count: `1`
- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Raw evidence: `not_exported`

## Citations

### Citation 2

- Citation ID: `cite_c23e93b0d8f29fad085549ce3e69a12b`
- Concept ID: `concepts/agent-execution-paths`
- Section ID: `concepts/agent-execution-paths#agent-execution-paths`
- Scope: `claim`
- Support: `supporting`
- Locator: `anchor=source_lines:34-67, heading=Execution structure is not node-level intelligence`
- Claim IDs: `claim_outer_structure_is_separate_from_node_logic`
- Review status: `dec_5e65310b419c0c66a498b255aa6e3fca`
- Derivation type: `human-reviewed-ai-assisted-synthesis`
