---
raw_evidence_exposed: false
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v1"
semantic_serving_enabled: false
source_card_id: "card_b9c636612d1fb60a4951a6a0db5f0611"
source_id: "source_m3_contract"
source_kind: "web"
---

# https://github.com/danielcanfly/knowledge-os-foundation

## Source

- URI: <https://github.com/danielcanfly/knowledge-os-foundation>
- Publisher: LLM Wiki Source
- Display host: `github.com`
- Retrieved at: `2026-07-02T12:20:00Z`
- Snapshot available: `true`
- Integrity SHA-256: `not_available`

## Provenance

- Citation count: `2`
- Concept count: `2`
- Claim count: `0`
- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Raw evidence: `not_exported`

## Citations

### Citation 3

- Citation ID: `cite_c27f20ede994b1ca98f229a1c7a3a7f8`
- Concept ID: `concepts/candidate-delivery-controls`
- Section ID: `concepts/candidate-delivery-controls#candidate-delivery-controls`
- Scope: `concept`
- Support: `supporting`
- Locator: `not specified`

### Citation 34

- Citation ID: `cite_f3284f3b48994f75de5c8660ccf80fee`
- Concept ID: `concepts/source-governance`
- Section ID: `concepts/source-governance#knowledge-source-governance`
- Scope: `concept`
- Support: `supporting`
- Locator: `not specified`
- Derivation type: `manual_review`
