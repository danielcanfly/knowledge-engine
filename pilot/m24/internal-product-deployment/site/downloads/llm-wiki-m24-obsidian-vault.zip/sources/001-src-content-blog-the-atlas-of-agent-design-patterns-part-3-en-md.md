---
raw_evidence_exposed: false
release_id: "20260720T160000Z-46137c97263e"
retrieval_authority: "lexical"
schema_version: "knowledge-engine-m24-obsidian-source-note/v1"
semantic_serving_enabled: false
source_card_id: "card_322a8062be535cf324072f1b697bd27e"
source_id: "source_blog_agent_planning_strategies"
source_kind: "web"
---

# src/content/blog/the-atlas-of-agent-design-patterns-part-3/en.md

## Source

- URI: <https://www.danielcanfly.com/en/blog/the-atlas-of-agent-design-patterns-part-3/>
- Publisher: LLM Wiki Source
- Display host: `danielcanfly.com`
- Retrieved at: `2026-07-08T03:29:20Z`
- Snapshot available: `true`
- Integrity SHA-256: `not_available`

## Provenance

- Citation count: `1`
- Concept count: `1`
- Claim count: `1`
- Retrieval authority: `lexical`
- Semantic serving: `disabled`
- Raw evidence: `not_exported`

## Citations

### Citation 1

- Citation ID: `cite_7681df13eda16979a0b2aaf7be0754a3`
- Concept ID: `concepts/agent-planning-strategies`
- Section ID: `concepts/agent-planning-strategies#adaptive-planning-and-replanning`
- Scope: `claim`
- Support: `supporting`
- Locator: `heading=Execution structure and decision strategy are different layers; A more precise map of the planning layer`
- Claim IDs: `claim_execution_structure_separate_from_decision_strategy`
- Review status: `dec_92fc06d1a4e249d2877df502d61e2d4e`
- Derivation type: `human-reviewed-ai-assisted-synthesis`
